export enum FollowRequestState {
    NONE = "none",
    DECLINED = "declined",
    PENDING = "pending",
    ACCEPTED = "accepted",
}
