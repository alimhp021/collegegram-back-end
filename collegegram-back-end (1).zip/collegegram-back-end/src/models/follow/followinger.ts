export type Followinger = {
    userName: string;
    followerCount: number;
    profileImage: string;
};
