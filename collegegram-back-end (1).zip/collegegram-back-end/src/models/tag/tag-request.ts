export type TagRequest = {
    postId: string;
    tag: string;
    isDeleted: boolean;
};
