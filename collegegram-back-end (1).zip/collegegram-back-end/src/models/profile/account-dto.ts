export type AccountDto = {
    userName: string,
    profileImage: string,
}