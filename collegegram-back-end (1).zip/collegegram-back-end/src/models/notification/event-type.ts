export enum EventType {
    LIKE = "like",
    FOLLOW = "follow",
    COMMENT = "comment",
    MENTION = "mention",
    FOLLOW_REQUEST = "followRequest",
}
